<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class product extends Model
{
    protected $table = 'products';

    protected $primaryKey = 'productid';

    protected $fillable = [
        'topUpid', 'product' , 'address' , 'price'
    ];
}
