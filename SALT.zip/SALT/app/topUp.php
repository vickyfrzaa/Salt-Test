<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class topUp extends Model
{
    protected $table = 'top_ups';

    protected $primaryKey = 'topUpid';

    protected $fillable = [
        'phone', 'value'
    ];
}
