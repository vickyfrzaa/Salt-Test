<?php

namespace App\Http\Controllers;

use App\history;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HistoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $viewOrder = DB::table('orders')
        ->join('products', 'products.productid', '=', 'orders.productid')
        ->join('top_ups', 'top_ups.topUpid', '=', 'products.topUpid')
        ->select('products.price', 'top_ups.value', 'top_ups.phone', 'orders.orderNo',
                DB::raw('(products.price + (5/100)) as totalBalance'), 
                DB::raw('(products.price + 10000) as totalProduct'))
        ->paginate(5);

        return view ('history')
        ->with('viewOrder', $viewOrder);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\history  $history
     * @return \Illuminate\Http\Response
     */
    public function show(history $history)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\history  $history
     * @return \Illuminate\Http\Response
     */
    public function edit(history $history)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\history  $history
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, history $history)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\history  $history
     * @return \Illuminate\Http\Response
     */
    public function destroy(history $history)
    {
        //
    }

    // Search
    public function search(Request $request)
    {
        $search = $request->get('search');

        $searchOrder = DB::table('orders')
        ->join('products', 'products.productid', '=', 'orders.productid')
        ->join('top_ups', 'top_ups.topUpid', '=', 'products.topUpid')
        ->select('products.price', 'top_ups.value', 'top_ups.phone', 'orders.orderNo',
                DB::raw('(products.price + (5/100)) as totalBalance'), 
                DB::raw('(products.price + 10000) as totalProduct'))
        ->where('orderNo', 'like', '%'.$search.'%')
        ->orderBy('date', 'ASC')
        ->paginate(5);


        if($search)
        {
            return view('searchHistory')
            ->with('searchOrder', $searchOrder);
        }
        else
        {
            return redirect('history');
            
        }
    }
}
