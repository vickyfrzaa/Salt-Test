<?php

namespace App\Http\Controllers;

use App\topUp;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class TopUpController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function index()
    {
        return view ('pair');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = request()->validate (
            ['phone' => 'required|string|between:7, 12'],
            ['value' => 'required'],
        );

        $data = new topUp();
        $data->phone = $request->input('phone');
        $data->value = $request->input('value');
        $data->save();

        return redirect('product');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\topUp  $topUp
     * @return \Illuminate\Http\Response
     */
    public function show(topUp $topUp)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\topUp  $topUp
     * @return \Illuminate\Http\Response
     */
    public function edit(topUp $topUp)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\topUp  $topUp
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, topUp $topUp)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\topUp  $topUp
     * @return \Illuminate\Http\Response
     */
    public function destroy(topUp $topUp)
    {
        //
    }
}
