<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pay extends Model
{
    protected $table = 'pays';

    protected $primaryKey = 'payid';

    protected $fillable = [
        'orderNo'
    ];
}
