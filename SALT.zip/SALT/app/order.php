<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class order extends Model
{
    protected $table = 'orders';

    protected $primaryKey = 'orderid';

    protected $fillable = [
        'productid', 'orderNo', 'totalBalance', 'totalProduct', 'date'
    ];
}
