<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth/login');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/pair', 'TopUpController@index')->name('pair');
Route::post('/pair', 'TopUpController@store')->name('pair');

Route::get('/product', 'productController@index')->name('product');
Route::post('/product', 'productController@store')->name('product');

Route::get('/order', 'orderController@index')->name('order');
Route::post('/order', 'orderController@store')->name('order');

Route::get('/pay', 'payController@index')->name('pay');
Route::post('/pay', 'payController@store')->name('pay');

Route::get('/history', 'historyController@index')->name('history');
Route::post('/history', 'historyController@store')->name('history');

Route::get('/search', 'historyController@search')->name('search');
