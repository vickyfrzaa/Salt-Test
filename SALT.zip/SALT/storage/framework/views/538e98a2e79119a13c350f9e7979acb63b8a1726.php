 

 <?php $__env->startSection('isiContent'); ?>
 <form method="POST" action="<?php echo e(route('pair')); ?>">
  <?php echo csrf_field(); ?>
    <section id="form-user">
    	<div class="container">
    		<h1 class="judul fs-1 fw-bolder mt-4 mb-4">Prepaid Balance</h1>
    		<div class="mb-3">
				<input value="<?php echo e(old('phone')); ?>" name="phone" type="text" class="form-control form-control-lg" id="exampleFormControlInput1" placeholder="Mobile Number" required/>
      </div>
			<select class="form-select form-select-lg" aria-label="Default select example" name="value">
        <option selected>Value</option>
        <option value="10.000">10.000</option>
        <option value="50.000">50.000</option>
        <option value="100.000">100.000</option>
      </select>
			<div class="d-grid gap-2" style="margin-top: 350px;">
  				<button class="btn-lg btn-primary" type="submit">Submit</button>
			</div>
    	</div>
    </section>
</form>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userSalt', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SALT\resources\views/pair.blade.php ENDPATH**/ ?>