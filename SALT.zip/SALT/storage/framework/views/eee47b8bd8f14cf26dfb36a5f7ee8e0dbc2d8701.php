<?php $__env->startSection('isiContent'); ?>
<form method="POST" action="<?php echo e(route('success')); ?>">
<?php echo csrf_field(); ?>
    <section id="success">
    	<div class="container">
    		<div class="row">
          <div class="col-lg-12">
            <div class="success-creaate">
              <h2 class="text-success pb-4 pt-4">Success!</h2>      
              <div class="row">
                <div class="col-md-6 col-sm-2">
                  <div class="text">
                    <h4>Order no.</h4>
                  </div>
                </div>
                <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-sm-2">
                  <div class="text fw-normal">
                    <h5><?php echo e($data->topUpid); ?></h5>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>

              <div class="row">
                <div class="col-md-6">
                  <div class="text">
                    <h4>Total</h4>
                  </div>
                </div>
                <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                  <div class="text fw-normal">
                    <h5>Rp. <?php echo e($data->price); ?></h5>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>

              <!-- <div class="row pt-4">
                <div class="col-md-6">
                  <div class="text">
                    <h4>Product Name</h4>
                  </div>
                </div>
                <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                  <div class="text fw-normal">
                    <h5>Price + 5%</h5>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>

              <div class="row pt-2">
                <div class="col-md-6">
                  <div class="text">
                    <h4>Address</h4>
                  </div>
                </div>
              </div> -->
            </div>
          </div>
          <div class="d-grid gap-2" style="margin-top: 400px;">
            <button class="btn btn-primary" type="submit">Pay now</button>
          </div>
        </div>
    	</div>
    </section>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userSalt', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SALT\resources\views/success.blade.php ENDPATH**/ ?>