<?php $__env->startSection('isiContent'); ?>
<form method="POST" action="<?php echo e(route('product')); ?>">
  <?php echo csrf_field(); ?>
  <?php $__currentLoopData = $topup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <input type="hidden" name="topUpid" value="<?php echo e($data->topUpid); ?>">
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <section id="product">
    	<div class="container">
    		<h1 class="judul fs-1 fw-bolder mt-4 mb-4">Product Page</h1>
    		<div class="mb-3">
          <textarea name="product" class="form-control form-control-lg" id="exampleFormControlTextarea1" placeholder="Product" rows="3"></textarea>
        </div>
        <div class="mb-3">
          <textarea name="address" class="form-control form-control-lg" id="exampleFormControlTextarea1" placeholder="Shipping Address" rows="3"></textarea>
        </div>
        <div class="mb-3">
          <input name="price" value="<?php echo e(old('price')); ?>" type="text" class="form-control form-control-lg" id="exampleFormControlInput1" placeholder="Price">
        </div>
        <div class="d-grid gap-2" style="margin-top: 150px;">
          <button class="btn-lg btn-primary" type="submit">Submit</button>
      </div>
    	</div>
    </section>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userSalt', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SALT\resources\views/product.blade.php ENDPATH**/ ?>