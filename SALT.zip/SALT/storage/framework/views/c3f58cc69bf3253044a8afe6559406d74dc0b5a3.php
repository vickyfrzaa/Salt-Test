<?php $__env->startSection('isiContent'); ?>
    <section id="pay">
    	<div class="container">
    		<h1 class="judul fs-1 fw-bolder mt-4 mb-4">Pay Your Order</h1>
    		<div class="mb-3">
				<input name="" value="" type="text" class="form-control form-control-lg" id="exampleFormControlInput1" placeholder="Order no." required/>
      </div>
			<div class="d-grid gap-2" style="margin-top: 350px;">
  				<button class="btn-lg btn-primary" type="submit">Submit</button>
			</div>
    	</div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userSalt', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SALT\resources\views/pay.blade.php ENDPATH**/ ?>