<?php $__env->startSection('isiContent'); ?>
    <section id="pay">
    	<div class="container">
    		<h1 class="judul fs-1 fw-bolder mt-4 mb-4">Order History</h1>
			<div class="container">
				<form action="<?php echo e(asset('search')); ?>" method="GET" class="d-flex">
					<input name="search" class="form-control me-2 form-control-lg" type="search" placeholder="Search by Order no." aria-label="Search">
				</form>
			</div>
    	</div>
		<?php $__currentLoopData = $viewOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="container pt-4">
		<ol class="list-group">
			<li class="list-group-item d-flex justify-content-between align-items-start">
			<div class="col">
				<div class="ms-2 me-auto">
					<div class="fw-bold"><?php echo e($data->orderNo); ?></div>
					<?php echo e($data->value); ?> | <?php echo e($data->phone); ?>

				</div>
			</div>
			<div class="col">
				<div class="ms-2 me-auto">
					<div class="fw-bold">Rp. <?php echo e($data->totalBalance); ?></div>	
				</div>
			</div>
				<button type="submit" class="btn-lg btn-primary">Pay Now</button>
			</li>
		</ol>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<nav class="pt-4" aria-label="Page navigation example">
			<ul class="pagination justify-content-center">
				<li class="page-item disabled">
					<a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
				</li>
				<li class="page-item"><a class="page-link" href="#">1</a></li>
				<li class="page-item"><a class="page-link" href="#">2</a></li>
				<li class="page-item"><a class="page-link" href="#">3</a></li>
				<li class="page-item">
					<a class="page-link" href="#">Next</a>
				</li>
			</ul>
		</nav>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userSalt', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SALT\resources\views/history.blade.php ENDPATH**/ ?>