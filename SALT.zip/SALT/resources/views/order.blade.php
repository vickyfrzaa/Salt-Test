@extends('layouts.userSalt')

@section('isiContent')
<form method="POST" action="{{ route('order') }}">
@csrf
@php 
  $random = rand(0000000000,9999999999); 
  $mytime = Carbon\Carbon::now();
  echo $mytime->toDateTimeString();
@endphp
@foreach ($order as $data)
  <input type="hidden" name="productid" value="{{ $data->productid }}">
  <input type="hidden" name="orderNo" value="{{ $random }}">
  <input type="hidden" name="totalBalance" value="{{ $data->totalBalance }}">
  <input type="hidden" name="totalProduct" value="{{ $data->totalProduct }}">
  <input type="hidden" name="date" value="{{ $mytime }}">
@endforeach
    <section id="success">
    	<div class="container">
    		<div class="row">
          <div class="col-lg-12">
            <div class="success-creaate">
              <h2 class="text-success pb-4 pt-4">Success!</h2>      
              <div class="row">
                <div class="col-md-6 col-sm-2">
                  <div class="text">
                    <h4>Order no.</h4>
                  </div>
                </div>
                @foreach ($order as $data)
                <div class="col-md-6 col-sm-2">
                  <div class="text fw-normal">
                    <h5>{{ $data->topUpid }}</h5>
                  </div>
                </div>
                @endforeach
              </div>

              <div class="row">
                <div class="col-md-6">
                  <div class="text">
                    <h4>Total</h4>
                  </div>
                </div>
                @foreach ($order as $data)
                <div class="col-md-6">
                  <div class="text fw-normal">
                    <h5>Rp. {{ $data->price }}</h5>
                  </div>
                </div>
                @endforeach
              </div>
            </div>
          </div>
          <div class="d-grid gap-2" style="margin-top: 400px;">
            <button class="btn-lg btn-primary" type="submit">Pay now</button>
          </div>
        </div>
    	</div>
    </section>
    </form>
@endsection
