@extends('layouts.userSalt')

@section('isiContent')
<form method="POST" action="{{ route('product') }}">
  @csrf
  @foreach ($topup as $data)
  <input type="hidden" name="topUpid" value="{{ $data->topUpid }}">
  @endforeach
    <section id="product">
    	<div class="container">
    		<h1 class="judul fs-1 fw-bolder mt-4 mb-4">Product Page</h1>
    		<div class="mb-3">
          <textarea name="product" class="form-control form-control-lg" id="exampleFormControlTextarea1" placeholder="Product" rows="3"></textarea>
        </div>
        <div class="mb-3">
          <textarea name="address" class="form-control form-control-lg" id="exampleFormControlTextarea1" placeholder="Shipping Address" rows="3"></textarea>
        </div>
        <div class="mb-3">
          <input name="price" value="{{ old('price') }}" type="text" class="form-control form-control-lg" id="exampleFormControlInput1" placeholder="Price">
        </div>
        <div class="d-grid gap-2" style="margin-top: 150px;">
          <button class="btn-lg btn-primary" type="submit">Submit</button>
      </div>
    	</div>
    </section>
</form>
@endsection
